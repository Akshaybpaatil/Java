package com.section4;

import java.util.Random;
import java.util.Scanner;

public class AccountMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		Account acc1 = new Account(2000);
		Account acc2 = new Account(3000);

		Random random = new Random();
		acc1.accNum = random.nextInt();
		acc2.accNum = random.nextInt();

		System.out.println("Smith Account Balance:" + acc1.getBalance() + " Account number is " + acc1.accNum);
		System.out.println("Kathy Account Balance:" + acc2.getBalance() + " Account number is " + acc2.accNum);

		// Deposit amount in Smith Account

		
		
		System.out.println( "Enter deposit amount for Smith: " );
		acc1.deposit(sc.nextDouble());
		
		//Withdraw amount from Kathy
		System.out.println( "Enter  amount be to Withdraw for kathy: " );
		acc2.withdraw(sc.nextDouble());
		
		//Balance After Transactions
		System.out.println("Updated Account Details-----------------");
		System.out.println("Smith Account Balance: " + acc1.getBalance());
		System.out.println("Kathy Account Balance: " + acc2.getBalance());
		
		System.out.println("ToString method------------------------------");
		System.out.println(acc1.toString());
		System.out.println(acc2.toString());
		
		System.out.println("1.Withdraw \n 2.Deposit \n 3. Balance \n 4.Logout");

	}

}
