package com.section4;

public class SavingsAccount extends Account {
	
	private double balance;
	final long minBal=1000;
	
	public double getBalance() {
		return balance;
	}
	@Override
	public double deposit(double amount) {
		if(amount<0) {
			System.out.println("Invalid amount");
		}else {
		balance = balance + amount;
			}
		return balance;
	}
	@Override
	public double withdraw(double amount) {
		if(amount<0) {
			System.out.println("Invalid amount");
		}else if((balance-amount)<minBal) {
			System.out.println("Minimun balance should be 1000");
		}else {
		balance = balance - amount;
		}
		return balance;
	}

}
