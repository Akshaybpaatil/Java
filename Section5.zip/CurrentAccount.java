package com.section4;

public class CurrentAccount extends Account {
	private double balance;
	
	final long minBal=1000;
	
	public double deposit(double amount) {
		if(amount<0) {
			System.out.println("Invalid Amount------------");
		}else {
			balance = balance + amount;
		}
		return balance;
	}
	public double withdraw(double amount) {
		if(amount<0) {
			System.out.println("Invalid amount");
		}else if((balance-amount)<minBal) {
			System.out.println("Minimum balance should be 10000-----------");
		}else {
		balance = balance - amount;
		}
		return balance;
	}

}
