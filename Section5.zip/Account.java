package com.section4;

public class Account {

	long accNum;
	double balance;
	Person accHolder;

	public Account(double initialBalance) {
		if (initialBalance > 0.0)
			balance = initialBalance;
	}	
	

	public Account() {
		super();
		
	}


	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double deposit(double amt) {

		if (amt < 0) {
			System.out.println("Invalid Amount");
		} else {
			balance = balance + amt;
			System.out.println("The Balance of Account Number" + accNum + "is" + balance);
		}
		return balance;

	}

	public double withdraw(double amt) {
		if (amt < 0) {
			System.out.println("Invalid amount");
		} else {
			balance = balance - amt;
			System.out.println("The Balance of Account Number" + accNum + "is" + balance);
		}
		return balance;
	}

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance + "]";
	}

}
